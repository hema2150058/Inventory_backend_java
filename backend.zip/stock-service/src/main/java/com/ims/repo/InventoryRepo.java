package com.ims.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ims.model.Inventory;

@Repository
public interface InventoryRepo extends JpaRepository<Inventory, Long>{
	
	List<Inventory> findInventoryByLocationNumber(String locationNumber);
	
	List<Inventory> findInventoryByMaterialName(String materialName);

	//List<Inventory> findAllByOrderByMaterialId();
	@Modifying
	@Query(value ="SET @count = 0; UPDATE inventory SET material_id = @count : =@count +1 ORDER BY material_id",nativeQuery = true)
	void reassignMaterialIds();
}
