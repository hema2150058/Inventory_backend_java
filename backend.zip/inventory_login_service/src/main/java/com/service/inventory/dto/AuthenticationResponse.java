package com.service.inventory.dto;

public class AuthenticationResponse {
	
	private String username;
	
	private String rolename;
	
	private String jwtAuthToken;

	private long serverCurrentTime;

	private long tokenExpirationTime;

	

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getRolename() {
		return rolename;
	}

	public void setRolename(String rolename) {
		this.rolename = rolename;
	}

	public String getJwtAuthToken() {
		return jwtAuthToken;
	}

	public void setJwtAuthToken(String jwtAuthToken) {
		this.jwtAuthToken = jwtAuthToken;
	}

	public long getServerCurrentTime() {
		return serverCurrentTime;
	}

	public void setServerCurrentTime(long serverCurrentTime) {
		this.serverCurrentTime = serverCurrentTime;
	}

	public long getTokenExpirationTime() {
		return tokenExpirationTime;
	}

	public void setTokenExpirationTime(long tokenExpirationTime) {
		this.tokenExpirationTime = tokenExpirationTime;
	}

	public AuthenticationResponse(String username, String rolename, String jwtAuthToken, long serverCurrentTime,
			long tokenExpirationTime) {
		
		this.username = username;
		this.rolename = rolename;
		this.jwtAuthToken = jwtAuthToken;
		this.serverCurrentTime = serverCurrentTime;
		this.tokenExpirationTime = tokenExpirationTime;
	}

	@Override
	public String toString() {
		return "AuthenticationResponse [username=" + username + ", rolename=" + rolename + ", jwtAuthToken="
				+ jwtAuthToken + ", serverCurrentTime=" + serverCurrentTime + ", tokenExpirationTime="
				+ tokenExpirationTime + "]";
	}	
	
}
