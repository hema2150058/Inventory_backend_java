package com.ims.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "`order`")
public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long orderId;
	private String locationNumber;
	private long materialId;
	private int orderQty;
	private String orderSatus;
	private String userName;
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Order(long orderId, String locationNumber, long materialId, int orderQty, String orderSatus, String userName) {
		super();
		this.orderId = orderId;
		this.locationNumber = locationNumber;
		this.materialId = materialId;
		this.orderQty = orderQty;
		this.orderSatus = orderSatus;
		this.userName = userName;
	}
	public long getOrderId() {
		return orderId;
	}
	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}
	public String getLocationNumber() {
		return locationNumber;
	}
	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}
	public long getMaterialId() {
		return materialId;
	}
	public void setMaterialId(long materialId) {
		this.materialId = materialId;
	}
	public int getOrderQty() {
		return orderQty;
	}
	public void setOrderQty(int orderQty) {
		this.orderQty = orderQty;
	}
	public String getOrderSatus() {
		return orderSatus;
	}
	public void setOrderSatus(String orderSatus) {
		this.orderSatus = orderSatus;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
}
