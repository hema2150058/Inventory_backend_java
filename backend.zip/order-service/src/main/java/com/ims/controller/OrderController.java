package com.ims.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ims.kafka.OrderProducer;
import com.ims.model.Order;
import com.ims.service.OrderService;

@RestController
@RequestMapping("/order")
@CrossOrigin(origins = "http://localhost:4200")
public class OrderController {
	
	@Autowired
	private OrderProducer orderProducer;
	
	@Autowired
	private OrderService orderService;
	
	@PostMapping("/placeOrder")//user
	public String placeOrder(@RequestBody Order order) {
		order.setOrderSatus("Pending");
		
		orderService.saveOrder(order);
		
		orderProducer.sendMessage(order);
		return "Order Placed  Successfully";
	}
	
	@GetMapping("/getAllOrders")//admin
	public List<Order> getAllProducts() {
		return orderService.getAllOrders();
	}
	
	@GetMapping("/getAllPendingOrders")//user and admin
	public List<Order> getAllPendingProducts() {
		return orderService.getAllPendingOrdersByStatus("Pending");
	}//this i have to ask whether i have to do it using username for user--------
	
	@GetMapping("/getOrdersByUserName/{userName}")//user
	public List<Order> getAllOrdersByUserName(@PathVariable String userName) {
		return orderService.findByUserName(userName);
	}
	
	@PatchMapping("/status/{id}")//admin approving order 
	public String changeStatus(@PathVariable long id) {
		//get Order by id
		Order order = orderService.getByOrderId(id).orElse(null);//and status is set to inactive and admin won't be able to change its status to completed
		
		//change the status to active
		if(order != null) {
			order.setOrderSatus("Accepted");
			orderService.saveOrder(order);
			orderProducer.sendMessage(order);
			return "Order status changed successfully";
		}
		
		
		return "Order Not found";
		
	}
	
	@DeleteMapping("/delete/{id}")//admin decline
	public void deleteOrder(@PathVariable(value = "id") long orderId) {
		Order order = orderService.getByOrderId(orderId).orElse(null);
		orderService.deleteOrder(order);
	}
	
	@PatchMapping("/edit/{id}/{qty}")//user
	public Order EditOrder(@PathVariable(value = "id") long orderId, @PathVariable(value = "qty") int orderQty) {
		Order order = orderService.getByOrderId(orderId).orElse(null);
		order.setOrderQty(orderQty);
		return orderService.saveOrder(order);
	}
	//list all orders by admin
	//list view all orders and their status by user
}
